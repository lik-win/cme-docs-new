import ImageCanvas from '../../../ImageCanvas.js';
import ImageSource from '../../../source/Image.js';
import {
  containsExtent,
  getHeight,
  getWidth,
  scaleFromCenter,
} from '../../../extent.js';
import axios from "axios" ;
import WindGL from "./index.js";
import { fromUrl, Pool } from "geotiff";
class ImageCanvasWindSource extends ImageSource {
    /**
     * @param {Options} [options] ImageCanvas options.
     */
    constructor(options) {
        options = options ? options : {};
        super({
            attributions: options.attributions,
            interpolate: options.interpolate,
            projection: options.projection,
            resolutions: options.resolutions,
            state: options.state,
        });
        this.options = options;
    //   /**
    //    * @private
    //    * @type {FunctionType}
    //    */
    //   this.canvasFunction_ = options.canvasFunction;
        this.loading = true;
        /**
         * @private
         * @type {import("../ImageCanvas.js").default}
         */
        this.canvas_ = null;

        /**
         * @private
         * @type {number}
         */
        this.renderedRevision_ = 0;

        /**
         * @private
         * @type {number}
         */
        this.ratio_ = options.ratio !== undefined ? options.ratio : 1.5;
        this.preSize = null;
        this.windData = null;
        // this.loadWindData();
    }

    _renderFunction(options){
        // return this.getCofTifData(options)
        return this.getCofTifData111(options)
    }
    /**
     * @param {import("../extent.js").Extent} extent Extent.
     * @param {number} resolution Resolution.
     * @param {number} pixelRatio Pixel ratio.
     * @param {import("../proj/Projection.js").default} projection Projection.
     * @return {import("../ImageCanvas.js").default} Single image.
     * @override
     */
    getImageInternal(extent, resolution, pixelRatio, projection) {
        resolution = this.findNearestResolution(resolution);
        let canvas = this.canvas_;
        if (
            canvas &&
            this.renderedRevision_ == this.getRevision() &&
            canvas.getResolution() == resolution &&
            canvas.getPixelRatio() == pixelRatio &&
            containsExtent(canvas.getExtent(), extent)
        ) {
            return canvas;
        }

        extent = extent.slice();
        scaleFromCenter(extent, this.ratio_);
        const width = getWidth(extent) / resolution;
        const height = getHeight(extent) / resolution;
        const size = [width * pixelRatio, height * pixelRatio];
        const canvasElement = this.canvasFunction(
            extent,
            resolution,
            pixelRatio,
            size,
            projection,
        );
        if (canvasElement) {
            canvas = new ImageCanvas(extent, resolution, pixelRatio, canvasElement);
        }
        this.canvas_ = canvas;
        this.renderedRevision_ = this.getRevision();
        return canvas;
    }
    /**
     * 
     */
    canvasFunction(extent, resolution, pixelRatio, size, projection){
        // console.log("extent:",extent);
        // console.log("resolution:",resolution);
        // console.log("pixelRatio:",pixelRatio);
        // console.log("projection:",projection.extent_);
        // console.log("size:",size);
        // this.preSize = size;
        let canvas = null;
        if (!this.canvasElement){
            canvas =  document.createElement('canvas');
            this.canvasElement = canvas;
            this._gl = this.createGL(canvas);
            this.wind = new WindGL(this._gl, this.options);
            // console.log("this.options.numParticles "+this.options.numParticles)
            this.wind.numParticles =  this.options.numParticles||15000;

        }else{
            canvas = this.canvasElement;
        }
        canvas.width = size[0];
        canvas.height = size[1];
        if (!this.loading){
            const bounds = this.getScaleBounds(extent,projection);
            this.wind.updateBounds(bounds);
            // console.log("preSize:",this.preSize,"size:",size,(this.preSize[0] != size[0] || this.preSize[1] != size[1]));
            if (this.preSize[0] != size[0] || this.preSize[1] != size[1]){
                this.wind.resize();
            }
            
            this.wind.draw();
        }
        this.preSize = size;
        return canvas;
    }
    /**
     * 加载图层相关的数据
     */
    loadWindData(){
        const jsonUrl = this.options.jsonUrl;
        const imageUrl = this.options.imageUrl;
        axios({
            method: 'get',
            url: jsonUrl,
            responseType: 'json'
        }).then(response=>{
            let windData = response.data
            const windImage = new Image();
            windData.image = windImage;
            windImage.src = imageUrl;

            windImage.onload =  ()=> {
               this.windData = windData;
            console.log("windData");

            console.log(windData)
               // 执行顺序
               this.wind.setWind(windData);
               this.wind.resize();
            //    this.wind.draw();
               this.loading = false;
            };
        });
         this.myaf = requestAnimationFrame(this._render.bind(this))
    }




     /**
     * 获取工作池，如果不存在则创建一个新的工作池并返回。
     *
     * @return {Pool} 工作池
     */
     getWorkerPool() {
        let workerPool
        if (!workerPool) {
            workerPool = new Pool();
        }
        return workerPool;
    }
    /**
+     * 从指定URL获取并处理COF TIF数据。
+     *
+     * @param {string} url - COF TIF数据的URL。
+     * @param {number} factor - 用于对TIF数据进行降采样的因子。
+     * @return {object} 包含处理后的TIF数据，新宽度和高度，无数据值和边界的对象。
+     */
    async getCofTifData(options) {

        let url=options.url;

        console.log("url",options)
        // let factor=options.factor||1;
        let factor=options.factor||1;
        console.log("factor",factor)

        // url, factor
        const tiff = await fromUrl(url);
        const image = await tiff.getImage();  //栅格数据
        const /* In the provided code snippet, the `width` variable is being used to calculate the
        width of the canvas element based on the extent and resolution. It is used in the
        `canvasFunction` method to determine the size of the canvas element that will be
        created or updated. */
        width = image.getWidth()
        const height = image.getHeight()
        const bounds = image.getBoundingBox()
        const nodata = image.getGDALNoData()
        // 计算抽稀后的宽高
        const newWidth = Math.floor(width / factor);
        const newHeight = Math.floor(height / factor);
        let minValue = 1e6
        let maxValue = -minValue
        const emptyPixels = new Uint8Array(width * height * 4)
        const data = await image.readRasters({ pool: this.getWorkerPool() })
        // 初始化抽稀后的像素数组
        const reducedChannel1Data = new Array(newWidth * newHeight).fill(0);
        const reducedChannel2Data = new Array(newWidth * newHeight).fill(0);

        console.log("width height ",newWidth,newHeight);

        const canvas = document.createElement('canvas');
        canvas.width = newWidth;
        canvas.height = newHeight;
        const ctx = canvas.getContext('2d');
        const imageData = ctx.createImageData(width, height);

      
        // 对每个抽稀像素进行计算
        for (let y = 0; y < height; y += factor) {
            for (let x = 0; x < width; x += factor) {
                const sourceX = Math.floor(x / factor);
                const sourceY = Math.floor(y / factor);
                const sourceIndex = y * width + x;
                const targetIndex = sourceY * newWidth + sourceX;
                // 累加抽稀区域内的像素值
                reducedChannel1Data[targetIndex] += data[0][sourceIndex];
                reducedChannel2Data[targetIndex] += data[1][sourceIndex];

                // imageData.data[i] =  data[0][sourceIndex];        // Red
                // imageData.data[i + 1] = data[1][sourceIndex];    // Green
                // imageData.data[i + 2] = 255;    // Blue
                // imageData.data[i + 3] = 1;      // Alpha (全透明)
                // i=i+4;
            }
        }


        console.log("reducedChannel2Data")
        console.log(reducedChannel2Data)

        let newData = [reducedChannel1Data, reducedChannel2Data]

        debugger
        // 抽稀逻辑结束
        const { min: uMin, max: uMax } = this.findMinMax(newData[0])
        const { min: vMin, max: vMax } = this.findMinMax(newData[1]);
                // 对每个抽稀像素进行计算
                let i=0;
                for (let y = 0; y < height; y += factor) {
                    for (let x = 0; x < width; x += factor) {
                        const sourceX = Math.floor(x / factor);
                        const sourceY = Math.floor(y / factor);
                         const sourceIndex = y * width + x;
                        // const targetIndex = sourceY * newWidth + sourceX;
                        // 累加抽稀区域内的像素值
                        // reducedChannel1Data[targetIndex] += data[0][sourceIndex];
                        // reducedChannel2Data[targetIndex] += data[1][sourceIndex];
    
                        let u= data[0][sourceIndex];
                        let v= data[1][sourceIndex];
                        // // emptyPixels[i] = Math.floor(255 * (u - uMin) / (uMax - uMin));
                        // // emptyPixels[i + 1] = Math.floor(255 * (v - vMin) / (vMax - vMin));
                        
           

                        // //  if(i/100==0){
                        // //     console.log( imageData.data[i])
                        // //  }
                        //  imageData.data[i] =  Math.floor(255 * (u - uMin) / (uMax - uMin));       
                        // //  console.log( imageData.data[i])
                        //  imageData.data[i + 1] =Math.floor(255 * (v - vMin) / (vMax - vMin));    // Green
                      
                        //  imageData.data[i + 2] = 255;    // Blue
                        //  imageData.data[i + 3] = 255;      // Alpha (全透明)

                                 // emptyPixels[i] = Math.floor(255 * (u - uMin) / (uMax - uMin));
                        // emptyPixels[i + 1] = Math.floor(255 * (v - vMin) / (vMax - vMin));
                        
           

                        //  if(i/100==0){
                        //     console.log( imageData.data[i])
                        //  }
                         imageData.data[i] =  255;       
                        //  console.log( imageData.data[i])
                         imageData.data[i + 1] =0;    // Green
                         imageData.data[i + 2] = 0;    // Blue
                         imageData.data[i + 3] = 255;      // Alpha (全透明)
                        // i=i+4;
                    }
                }
    
        console.log("width height ",canvas.width,canvas.height);
        ctx.putImageData(imageData, 0, 0);
        const dataURL =canvas.toDataURL()
        console.log('Data URL:', dataURL);  // 输出 Data URL
        this.downloadDataURL(dataURL,"aaaaa.png")

        // this.windData.width = newWidth
        // this.windData.height = newHeight
        // this.windData.uMin = uMin
        // this.windData.uMax = uMax 
        // this.windData.vMin = vMin
        // this.windData.vMax = vMax
        let  windData={
                "image":dataURL,
                "date": "2024090512_021",
                "mode": null,
                "width": newWidth,
                "height": newHeight,
                "minzoom": 0,
                "maxzoom": 0,
                "tiles": "wind/single/2024090512_021/0/0/0.jpg",
                "uMax": uMax,
                "uMin": uMin,
                "vMax": vMax,
                "vMin": vMin
            };

            const windImage = new Image();
            windData.image = windImage;
            windImage.src = dataURL;
            windImage.onload =  ()=> {
                this.wind.setWind(windData);
                this.wind.resize();
             //    this.wind.draw();
                this.loading = false;
            }

        this.myaf = requestAnimationFrame(this._render.bind(this))
        // // console.log("uMin--uMax",uMin,uMax)
        // // console.log("vMin--vMax",vMin,vMax)
        // // this.windData.uMin = uMin / this.windData.scala
        // // this.windData.uMax = uMax / this.windData.scala
        // // this.windData.vMin = vMin / this.windData.scala
        // // this.windData.vMax = vMax / this.windData.scala
        // this.windData.bounds = this.formatBounds(bounds)//计算边界 tif的范围
        // this.windData.StableBox = this.formatBounds(bounds)
        // return { newData, newWidth, newHeight, nodata, bounds }
    }

    async getCofTifData111(options) {

        let url=options.url;

        console.log("url",options)
        // let factor=options.factor||1;
        let factor=options.factor||1;
        console.log("factor",factor)

        // url, factor
        const tiff = await fromUrl(url);
        const image = await tiff.getImage();  //栅格数据
         /* In the provided code snippet, the `width` variable is being used to calculate the
        width of the canvas element based on the extent and resolution. It is used in the
        `canvasFunction` method to determine the size of the canvas element that will be
        created or updated. */
        const width = image.getWidth()
        const height = image.getHeight()
        const bounds = image.getBoundingBox()
        const nodata = image.getGDALNoData()




            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            const imageData = ctx.createImageData(width, height);
    
                // 获取图像的像素数据
                const raster = await image.readRasters();
                const data = raster[0]; // 读取第一个波段的数据
                const data1 = raster[1]; // 读取第一个波段的数据

                console.log(data)
                console.log(data1)
                // 创建 ImageData 对象
                const dataArray = imageData.data;
                
                // 将 TIFF 数据转换为 RGBA 格式
                for (let i = 0; i < data.length; i++) {
                  const value = data[i];
                  dataArray[i * 4] = value;       // R
                  dataArray[i * 4 + 1] = data1[i];   // G
                  dataArray[i * 4 + 2] = 0;   // B
                  dataArray[i * 4 + 3] = 255;     // A (不透明)
                }
                // 绘制到 canvas
                ctx.putImageData(imageData, 0, 0);
    
                // 获取 Canvas 的 Data URL
                let dataUrl = canvas.toDataURL();

                this.downloadDataURL(dataUrl,"image1.png")
         
    
       

    }
     downloadDataURL(dataURL, fileName) {
        const a = document.createElement('a');
        a.href = dataURL;
        a.download = fileName;  // 下载的文件名
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }


    // 求最大值 最小值 O（n）
    findMinMax(array) {
        if (array.length === 0) {
            return null; // 数组为空时返回 null
        }
        let min = array[0];
        let max = array[0];

        for (let i = 1; i < array.length; i++) {
            if (array[i] < min) {
                min = array[i];
            } else if (array[i] > max) {
                max = array[i];
            }
        }

        return { min, max };
    }

    getScaleBounds(extent,projection){
        const projExtent = projection.extent_;
        const xLength = projExtent[2] - projExtent[0];
        const yLength = projExtent[3] - projExtent[1];
        return [
            (extent[0] -projExtent[0]) / xLength -0.5,
            (extent[2] -projExtent[0]) / xLength -0.5,
            (extent[1] -projExtent[1]) / yLength,
            (extent[3] -projExtent[1]) / yLength,
        ];
    }
    _render(){
        if (this.wind && this.wind.windData) {
            this.wind.draw();
            this.changed();
        }
         this.myaf =  requestAnimationFrame(this._render.bind(this));
    }

    /***
     * 创建获取 webgl对象
     */
    createGL(canvas) {
       let _glOpts =  {antialiasing: true,alpha:true}
        var gl =
            canvas.getContext('webgl', _glOpts) ||
            canvas.getContext('experimental-webgl', _glOpts);
        if(gl) {
            let _anisoExt =
                gl.getExtension('EXT_texture_filter_anisotropic') ||
                gl.getExtension('MOZ_EXT_texture_filter_anisotropic') ||
                gl.getExtension('WEBKIT_EXT_texture_filter_anisotropic');

            if(!_anisoExt) {
                console.warn('Your browser doesn`t support anisotropic filtering.  Ordinary MIP mapping will be used.');
            }
            //this._glResources = this._setupGlContext(gl);
        } else {
            console.warn('Your browser doesn`t seem to support WebGL.');
        }
        return gl;
    }

    _remove(){
        cancelAnimationFrame(this.myaf);
    }
    
}
  

export default ImageCanvasWindSource;