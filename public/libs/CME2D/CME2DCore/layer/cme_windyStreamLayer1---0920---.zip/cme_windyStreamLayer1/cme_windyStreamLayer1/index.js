import * as util from './util.js';


/**
 * u_wind 对应 this.windTexture - 风纹理数据
 * u_wind_min 在 this.windData 里面的(uMin,vMin)
 * u_wind_max 在 this.windData 里面的(uMax,vMax)
 * u_color_ramp 对应 this.colorRampTexture - 颜色数据纹理
 *
 * mix(x,y,a) 返回 x 和 y 的线性混合， x*(1-a) + y*a
 * length 返回矢量的长度layerExtent
 *
 * velocity 使用 mix 每个像素得到新的值，见 https://www.cnblogs.com/laizhenghong2012/p/11253100.html
 *
 */
const drawFrag = `precision mediump float;
uniform sampler2D u_wind;
varying vec2 v_particle_pos;
uniform vec4 bounds;
uniform int projCode;
uniform vec4 layerExtent;
vec2 posTouv(vec2 pos, vec4 bounds) {
    float u = bounds.x + (bounds.y - bounds.x) * pos.x;
    float v = bounds.z + (bounds.w - bounds.z) * pos.y;
    vec2 uv_pos = vec2(u, 1.0 - v);
    return uv_pos;
}
const float PI = 3.14159265359;
vec2 mercatorToWGS84(vec2 xy) {

    if(projCode==4326){
      return vec2(mod(xy.x, 1.0), xy.y);
    }
    else if(projCode==3857){
         float y = radians(180.0 - xy.y * 360.0);
        y = 360.0 / PI * atan(exp(y)) - 90.0;
        y = y / -180.0 + 0.5;
    //坐标转换   4326就采用下面一行代码就行了
     return vec2(mod(xy.x, 1.0), y);
    }

    
}

void main() {
    vec2 uv_pos = posTouv(v_particle_pos, bounds);
      vec2 pt= mercatorToWGS84(uv_pos);
    vec4 pos = texture2D(u_wind, mercatorToWGS84(uv_pos));
    gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0) * pos.b;
}`



/**
 * a_index 对应 this.particleIndexBuffer - 粒子索引数据
 * u_particles_res 对应 this.particleStateResolution - 粒子总数平方根
 * u_particles 对应 this.particleStateTexture - 每个粒子状态的纹理
 *
 * floor(x) ： 返回小于等于x的最大整数值
layer *
 * fract(a_index/u_particles_res) 一定会返回小于 1 的值，用于水平方向的颜色采样， 注意纹理坐标范围是 0-1
 * floor(a_index/u_particles_res)/u_particles_res) 一定会返回小于 1 的值，用于垂直方向的颜色采样
 *
 * color 得到的值就是获取粒子的状态中存储的颜色值，请记住这些颜色值都是根据速度生成的
 *
 * v_particle_pos 根据 color 就得到速度对应映射值
 *
 */

const drawVert = `precision mediump float;
attribute float a_index;
uniform sampler2D u_particles;
uniform float u_particles_res;
varying vec2 v_particle_pos;
varying vec2 v_webgl_pos;

void main() {
    vec4 color = texture2D(u_particles, vec2(fract(a_index / u_particles_res), floor(a_index / u_particles_res) / u_particles_res));
    v_particle_pos = vec2(color.r / 255.0 + color.b, color.g / 255.0 + color.a);
    v_webgl_pos = vec2(2.0 * v_particle_pos - 1.0);
    gl_PointSize = 1.0;
    gl_Position = vec4(v_webgl_pos.x, v_webgl_pos.y, 0, 1);
}`

const quadVert = `precision mediump float;

attribute vec2 a_pos;

varying vec2 v_tex_pos;

void main() {
    v_tex_pos = a_pos;
    gl_Position = vec4(1.0 - 2.0 * a_pos, 0, 1);
}`

const screenFrag = `precision mediump float;

uniform sampler2D u_screen;
uniform float u_opacity;

varying vec2 v_tex_pos;

void main() {
    vec4 color = texture2D(u_screen, 1.0 - v_tex_pos);
    gl_FragColor = vec4(floor(255.0 * color * u_opacity) / 255.0);
}`


const updateFrag = `precision highp float;
uniform sampler2D u_particles;
uniform sampler2D u_wind;
uniform vec2 u_wind_res;
uniform vec2 u_wind_min;
uniform vec2 u_wind_max;
uniform float u_rand_seed;
uniform float u_speed_factor;
uniform float u_drop_rate;
uniform float u_drop_rate_bump;
varying vec2 v_tex_pos;
uniform vec4 bounds;
uniform int projCode;
uniform vec4 layerExtent;

const vec3 rand_constants = vec3(12.9898, 78.233, 4375.85453);
float rand(const vec2 co) {
    float t = dot(rand_constants.xy, co);
    return fract(sin(t) * (rand_constants.z + t));
}

vec2 lookup_wind(const vec2 uv) {
    vec2 px = 1.0 / u_wind_res;
    vec2 vc = (floor(uv * u_wind_res)) * px;
    vec2 f = fract(uv * u_wind_res);
    vec2 tl = texture2D(u_wind, vc).rg;
    vec2 tr = texture2D(u_wind, vc + vec2(px.x, 0)).rg;
    vec2 bl = texture2D(u_wind, vc + vec2(0, px.y)).rg;
    vec2 br = texture2D(u_wind, vc + px).rg;
    return mix(mix(tl, tr, f.x), mix(bl, br, f.x), f.y);
}

vec2 posTouv(vec2 pos) {
    float u = bounds.x + (bounds.y - bounds.x) * pos.x;
    float v = bounds.z + (bounds.w - bounds.z) * pos.y;
    vec2 uv_pos = vec2(u, 1.0 - v);
    return uv_pos;
}

vec2 uvTopos(vec2 uv) {
    float x = (uv.x - bounds.x) / (bounds.y - bounds.x);
    float y = (uv.y - bounds.z) / (bounds.w - bounds.z);
    vec2 pos = vec2(x, y);
    return pos;
}
const float PI = 3.14159265359;
vec2 mercatorToWGS84(vec2 xy) {
    if(projCode==4326){
      return vec2(mod(xy.x, 1.0), xy.y);
    }
    else if(projCode==3857){
         float y = radians(180.0 - xy.y * 360.0);
        y = 360.0 / PI * atan(exp(y)) - 90.0;
        y = y / -180.0 + 0.5;
        
    //坐标转换   4326就采用下面一行代码就行了
     return vec2(mod(xy.x, 1.0), y);
    }
 
}
vec2 wgs84ToMercator(vec2 xy) {
    float y = -180.0 * xy.y + 90.0;
    y = (180.0 - (180.0 / PI * log(tan(PI / 4.0 + y * PI / 360.0)))) / 360.0;
    return vec2(xy.x, y);
}

// bool isPointInRect(vec2 pt, vec4 rect) {
//     return pt.x >= rect.x && pt.x <= rect.y &&
//            pt.y >= rect.z && pt.y <= rect.w;
// }

 bool isPointInRect(vec2 pt, vec4 rect) {
    return all(greaterThanEqual(pt, rect.xz)) && all(lessThanEqual(pt, rect.yw));

    // rect.xy: 代表矩形的左下角 (minX, minY)，即 vec2(rect.x, rect.y)。
    // rect.zw: 代表矩形的右上角 (maxX, maxY)，即 vec2(rect.z, rect.w)。
    // greaterThanEqual(pt, rect.xy): 判断点的 x 和 y 是否大于或等于矩形的左下角。
    // lessThanEqual(pt, rect.zw): 判断点的 x 和 y 是否小于或等于矩形的右上角。
    // all(): 检查所有条件是否为 true。

 }

void main() {
    vec4 color = texture2D(u_particles, v_tex_pos);
    vec2 pos = vec2(color.r / 255.0 + color.b, color.g / 255.0 + color.a);
    vec2 uv_pos = posTouv(pos);
    vec2 velocity = mix(u_wind_min, u_wind_max, lookup_wind(mercatorToWGS84(uv_pos)));
    float speed_t = length(velocity) / length(u_wind_max);

    float distortion = cos(radians(pos.y * 180.0 - 90.0));

    vec2 offset = vec2(velocity.x, velocity.y) * 0.0001 * u_speed_factor;

    pos = fract(1.0 + pos + offset);
    vec2 seed = (pos + v_tex_pos) * u_rand_seed;

    float drop_rate = u_drop_rate + speed_t * u_drop_rate_bump;
    float drop = step(1.0 - drop_rate, rand(seed));
    vec2 random_pos = vec2(rand(seed + 1.3), rand(seed + 2.1));
    pos = mix(pos, random_pos, drop);

      vec2 pt= mercatorToWGS84(uv_pos);

    // vec4 test=vec4(layerExtent.x,layerExtent.y,layerExtent.z,layerExtent.w);
        
    // [0.3190576154920789,0.326553495619032,0.7173354983859591,0.7244422793918185]
    // if(isPointInRect(pt,vec4(0.7, 0.0, 0.6, 0.6))){
    //  if(isPointInRect(pt,vec4(0.306,0.3612,0.612,0.723))){
    //  if(isPointInRect(pt,vec4(0.306,0.612,0.3612,0.723))){
    
        //中国区域
        // [0.6944027777777778,0.9028194444444444,0.554722222255489,0.8339722111077844]

        //    [0.6944027777777778,0.9028194444444444,0.5554722222255489,0.8339722111077844]
        //    [0.6944,0.90282,0.55547,0.83397]

        // if(isPointInRect(pt,vec4(0.6944,0.90282,0.55547,0.83397))){

        //  if(isPointInRect(pt,vec4(0.6944,0.90282,0.55547,0.83397))){

        if(isPointInRect(pt,vec4( layerExtent.x,layerExtent.z,layerExtent.y,layerExtent.w))){

         gl_FragColor = vec4(fract(pos * 255.0), floor(pos * 255.0) / 255.0);
        }

        // gl_FragColor = vec4(fract(pos * 255.0), floor(pos * 255.0) / 255.0,0.0,1.0);
        //  gl_FragColor = vec4(fract(pos * 255.0), floor(pos * 255.0) / 255.0);
        
    



}`


export default class WindGL {
    constructor(gl, options) {
        // 初始化配置信息
        this.gl = gl;

        // debugger
        // this.fadeOpacity = 0.996; // how fast the particle trails fade on each frame

        // this.speedFactor = 0.25; // how fast the particles move

        // this.dropRate = 0.003; // how often the particles move to a random place
        this.dropRateBump = options.dropRateBump || 0.01; // drop rate increase relative to individual particle speed
        //载入Progrogram

        this.fadeOpacity = options.fadeOpacity || 0.996;
        this.speedFactor = options.speedFactor || 0.45;
        this.dropRate = options.dropRate || 0.001;


        // console.log("  this.dropRateBump",  this.dropRateBump)
        // console.log("  this.fadeOpacity",  this.fadeOpacity)
        // console.log("  this.speedFactor",  this.speedFactor)
        // console.log("  this.dropRate",  this.dropRate)

        this.drawProgram = util.createProgram(gl, drawVert, drawFrag);

        this.screenProgram = util.createProgram(gl, quadVert, screenFrag);
        this.updateProgram = util.createProgram(gl, quadVert, updateFrag);

        this.quadBuffer = util.createBuffer(gl, new Float32Array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1]));


        this.framebuffer = gl.createFramebuffer();
        // 
        // this.setColorRamp(defaultRampColors);
        this.resize();
    }

    resize() {
        const gl = this.gl;
        const emptyPixels = new Uint8Array(gl.canvas.width * gl.canvas.height * 4);
        // screen textures to hold the drawn screen for the previous and the current frame
        this.backgroundTexture = util.createTexture(gl, gl.NEAREST, emptyPixels, gl.canvas.width, gl.canvas.height);
        this.screenTexture = util.createTexture(gl, gl.NEAREST, emptyPixels, gl.canvas.width, gl.canvas.height);
    }
    updateBounds(bounds) {
        this.bounds = bounds;
         console.log("  this.bounds",  JSON.stringify(this.bounds))
        const gl = this.gl;
        gl.useProgram(this.drawProgram.program);
        gl.uniform4f(this.drawProgram.bounds, bounds[0], bounds[1], bounds[2], bounds[3]);
        gl.useProgram(this.updateProgram.program);
        gl.uniform4f(this.updateProgram.bounds, bounds[0], bounds[1], bounds[2], bounds[3]);
    }

    set numParticles(numParticles) {
        const gl = this.gl;

        // we create a square texture where each pixel will hold a particle position encoded as RGBA
        const particleRes = this.particleStateResolution = Math.ceil(Math.sqrt(numParticles));
        this._numParticles = particleRes * particleRes;

        const particleState = new Uint8Array(this._numParticles * 4);
        for (let i = 0; i < particleState.length; i++) {
            particleState[i] = Math.floor(Math.random() * 256); // randomize the initial particle positions
        }
        // textures to hold the particle state for the current and the next frame
        this.particleStateTexture0 = util.createTexture(gl, gl.NEAREST, particleState, particleRes, particleRes);
        this.particleStateTexture1 = util.createTexture(gl, gl.NEAREST, particleState, particleRes, particleRes);

        const particleIndices = new Float32Array(this._numParticles);
        for (let i = 0; i < this._numParticles; i++) particleIndices[i] = i;
        this.particleIndexBuffer = util.createBuffer(gl, particleIndices);
    }
    get numParticles() {
        return this._numParticles;
    }
    setWind(windData) {
        this.windData = windData;
        this.windTexture = util.createTexture(this.gl, this.gl.LINEAR, windData.image);
    }
    draw() {

        // console.log("11111")
        const gl = this.gl;
        gl.disable(gl.DEPTH_TEST);
        gl.disable(gl.STENCIL_TEST);

        util.bindTexture(gl, this.windTexture, 0);
        util.bindTexture(gl, this.particleStateTexture0, 1);

        this.drawScreen();
        this.updateParticles();
    }

    drawScreen() {
        const gl = this.gl;
        // draw the screen into a temporary framebuffer to retain it as the background on the next frame
        util.bindFramebuffer(gl, this.framebuffer, this.screenTexture);
        gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

        this.drawTexture(this.backgroundTexture, this.fadeOpacity);
        this.drawParticles();

        util.bindFramebuffer(gl, null);
        // enable blending to support drawing on top of an existing background (e.g. a map)
        // http://t.zoukankan.com/hammerc-p-11459275.html
        // gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        this.drawTexture(this.screenTexture, 1.0);
        gl.disable(gl.BLEND);

        // save the current screen as the background for the next frame
        const temp = this.backgroundTexture;
        this.backgroundTexture = this.screenTexture;
        this.screenTexture = temp;
    }

    drawTexture(texture, opacity) {
        const gl = this.gl;
        const program = this.screenProgram;
        gl.useProgram(program.program);

        util.bindAttribute(gl, this.quadBuffer, program.a_pos, 2);
        util.bindTexture(gl, texture, 2);
        gl.uniform1i(program.u_screen, 2);
        gl.uniform1f(program.u_opacity, opacity);

        gl.drawArrays(gl.TRIANGLES, 0, 6);
        //gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }

    drawParticles() {
        const gl = this.gl;
        const program = this.drawProgram;
        gl.useProgram(program.program);

        util.bindAttribute(gl, this.particleIndexBuffer, program.a_index, 1);
        gl.uniform1i(program.u_particles, 1);
        gl.uniform1f(program.u_particles_res, this.particleStateResolution);
        gl.uniform1i(program.u_wind, 0);
        gl.uniform2f(program.u_wind_min, this.windData.uMin, this.windData.vMin);
        gl.uniform2f(program.u_wind_max, this.windData.uMax, this.windData.vMax);

        gl.uniform1i(program.projCode, this.windData.projCode);

        let layerExtent = this.windData.layerExtent;

        // console.log("Layer extent: " + layerExtent)

        gl.uniform1i(program.layerExtent, layerExtent[0], layerExtent[1], layerExtent[2], layerExtent[3]);

        util.bindTexture(this.gl, this.icontexture, 2);
        gl.uniform1i(program.u_icon, 2);


        gl.drawArrays(gl.POINTS, 0, this._numParticles);
        // util.bindTexture(gl, this.colorRampTexture, 2);
        // gl.uniform1i(program.u_color_ramp, 2);
        // gl.drawArrays(gl.POINTS, 0, this._numParticles);
        // gl.uniform1i(program.u_color_ramp, 2);



    }

    updateParticles() {

        let u_projectionType = 4326;
        const gl = this.gl;
        util.bindFramebuffer(gl, this.framebuffer, this.particleStateTexture1);
        gl.viewport(0, 0, this.particleStateResolution, this.particleStateResolution);

        const program = this.updateProgram;
        gl.useProgram(program.program);

        util.bindAttribute(gl, this.quadBuffer, program.a_pos, 2);

        gl.uniform1i(program.u_wind, 0);
        gl.uniform1i(program.u_particles, 1);

        gl.uniform1f(program.u_rand_seed, Math.random());
        gl.uniform2f(program.u_wind_res, this.windData.width, this.windData.height);
        gl.uniform2f(program.u_wind_min, this.windData.uMin, this.windData.vMin);
        gl.uniform2f(program.u_wind_max, this.windData.uMax, this.windData.vMax);
        gl.uniform1f(program.u_speed_factor, this.speedFactor);
        gl.uniform1f(program.u_drop_rate, this.dropRate);
        gl.uniform1f(program.u_drop_rate_bump, this.dropRateBump);

        gl.uniform1i(program.projCode, this.windData.projCode);

        let layerExtent = this.windData.layerExtent;

        gl.uniform1i(program.layerExtent, layerExtent[0], layerExtent[1], layerExtent[2], layerExtent[3]);

        gl.uniform1i(program.layerExtent, this.windData.layerExtent);
        // console.log("u_projectionType",u_projectionType)
        // gl.uniform1i(program.u_projectionType, u_projectionType);


        gl.drawArrays(gl.TRIANGLES, 0, 6);

        // swap the particle state textures so the new one becomes the current one
        const temp = this.particleStateTexture0;
        this.particleStateTexture0 = this.particleStateTexture1;
        this.particleStateTexture1 = temp;
    }
}