let  drawFrag =`precision mediump float;
uniform sampler2D u_wind;
varying vec2 v_particle_pos;
uniform vec4 bounds;
vec2 posTouv(vec2 pos, vec4 bounds) {
    float u = bounds.x + (bounds.y - bounds.x) * pos.x;
    float v = bounds.z + (bounds.w - bounds.z) * pos.y;
    vec2 uv_pos = vec2(u, 1.0 - v);
    return uv_pos;
}

const float PI = 3.14159265359;
vec2 mercatorToWGS84(vec2 xy) {
    float y = radians(180.0 - xy.y * 360.0);
    y = 360.0 / PI * atan(exp(y)) - 90.0;
    y = y / -180.0 + 0.5;
    //坐标转换   4326就采用下面一行代码就行了
    return vec2(mod(xy.x, 1.0), y);
}

void main() {
    vec2 uv_pos = posTouv(v_particle_pos, bounds);
    vec4 pos = texture2D(u_wind, mercatorToWGS84(uv_pos));

    gl_FragColor = vec4(1.0, 1.0, 1.0, 1.0) * pos.b;
}`

export default drawFrag;