let updateFrag=`
precision highp float;
uniform sampler2D u_particles;
uniform sampler2D u_wind;
uniform vec2 u_wind_res;
uniform vec2 u_wind_min;
uniform vec2 u_wind_max;
uniform float u_rand_seed;
uniform float u_speed_factor;
uniform float u_drop_rate;
uniform float u_drop_rate_bump;
varying vec2 v_tex_pos;
uniform vec4 bounds;

const vec3 rand_constants = vec3(12.9898, 78.233, 4375.85453);
float rand(const vec2 co) {
    float t = dot(rand_constants.xy, co);
    return fract(sin(t) * (rand_constants.z + t));
}

vec2 lookup_wind(const vec2 uv) {
    vec2 px = 1.0 / u_wind_res;
    vec2 vc = (floor(uv * u_wind_res)) * px;
    vec2 f = fract(uv * u_wind_res);
    vec2 tl = texture2D(u_wind, vc).rg;
    vec2 tr = texture2D(u_wind, vc + vec2(px.x, 0)).rg;
    vec2 bl = texture2D(u_wind, vc + vec2(0, px.y)).rg;
    vec2 br = texture2D(u_wind, vc + px).rg;
    return mix(mix(tl, tr, f.x), mix(bl, br, f.x), f.y);
}

vec2 posTouv(vec2 pos) {
    float u = bounds.x + (bounds.y - bounds.x) * pos.x;
    float v = bounds.z + (bounds.w - bounds.z) * pos.y;
    vec2 uv_pos = vec2(u, 1.0 - v);
    return uv_pos;
}

vec2 uvTopos(vec2 uv) {
    float x = (uv.x - bounds.x) / (bounds.y - bounds.x);
    float y = (uv.y - bounds.z) / (bounds.w - bounds.z);
    vec2 pos = vec2(x, y);
    return pos;
}
const float PI = 3.14159265359;
vec2 mercatorToWGS84(vec2 xy) {
    float y = radians(180.0 - xy.y * 360.0);
    y = 360.0 / PI * atan(exp(y)) - 90.0;
    y = y / -180.0 + 0.5;
    return vec2(mod(xy.x, 1.0), y);
}
vec2 wgs84ToMercator(vec2 xy) {
    float y = -180.0 * xy.y + 90.0;
    y = (180.0 - (180.0 / PI * log(tan(PI / 4.0 + y * PI / 360.0)))) / 360.0;
    return vec2(xy.x, y);
}

void main() {
    vec4 color = texture2D(u_particles, v_tex_pos);
    vec2 pos = vec2(color.r / 255.0 + color.b, color.g / 255.0 + color.a);
    vec2 uv_pos = posTouv(pos);
    vec2 velocity = mix(u_wind_min, u_wind_max, lookup_wind(mercatorToWGS84(uv_pos)));
    float speed_t = length(velocity) / length(u_wind_max);

    float distortion = cos(radians(pos.y * 180.0 - 90.0));

    vec2 offset = vec2(velocity.x, velocity.y) * 0.0001 * u_speed_factor;

    pos = fract(1.0 + pos + offset);
    vec2 seed = (pos + v_tex_pos) * u_rand_seed;

    float drop_rate = u_drop_rate + speed_t * u_drop_rate_bump;
    float drop = step(1.0 - drop_rate, rand(seed));

    vec2 random_pos = vec2(rand(seed + 1.3), rand(seed + 2.1));

    pos = mix(pos, random_pos, drop);

    gl_FragColor = vec4(fract(pos * 255.0), floor(pos * 255.0) / 255.0);
}`
export default updateFrag;
