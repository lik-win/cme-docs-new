let drawVert=`precision mediump float;
attribute float a_index;
uniform sampler2D u_particles;
uniform float u_particles_res;
varying vec2 v_particle_pos;
varying vec2 v_webgl_pos;

void main() {
    vec4 color = texture2D(u_particles, vec2(fract(a_index / u_particles_res), floor(a_index / u_particles_res) / u_particles_res));
    v_particle_pos = vec2(color.r / 255.0 + color.b, color.g / 255.0 + color.a);
    v_webgl_pos = vec2(2.0 * v_particle_pos - 1.0);
    gl_PointSize = 1.0;
    gl_Position = vec4(v_webgl_pos.x, v_webgl_pos.y, 0, 1);
}`
export default drawVert