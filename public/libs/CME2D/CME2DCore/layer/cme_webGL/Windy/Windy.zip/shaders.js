export const vShaderCalculate = `#version 300 es
layout(location=0) in float ix;
layout(location=1) in float iy;
layout(location=2) in float iLife;
layout(location=3) in vec4 iColor;
uniform sampler2D u_texture;

out float ox;
out float oy;
out float oLife;
out vec4 oColor;

// 风场原始数据值范围,调用cme_pngWindyWebGLLayer时传入
uniform vec4 u_val_extent;
// 地图可视范围，已做归一化处理,范围-1~1,[minX, minY, maxX, maxY]
uniform vec4 u_extent;
uniform float u_speed;
uniform float u_proj;

const vec3 rand_constants = vec3(12.9898, 78.233, 4375.85453);
float random(const vec2 co) {
  float t = dot(rand_constants.xy, co);
  return fract(sin(t) * (rand_constants.z + t));
}

const float PI = 3.14159265359;
float toWGS84(float y) {
  float newY = radians(180.0 - y * 360.0);
  newY = 360.0 / PI * atan(exp(newY)) - 90.0;
  return (newY / - 180.0 + 0.5);
}


// 根据传入的x、y坐标获取纹理坐标(x、y由utils.js中的generateParticle方法生成, 范围为-1~1)
vec2 getTexCoord(float x, float y) {
  // 地图可视区域相对完整地图的缩放范围,因已做归一化处理, 因此分母为2
  // 因在外面没有限制extent经纬度在 -180 ~ 180 或 0 ~ 360 度, 故u_extent的x坐标值可能不在 -1 ~ 1 之间
  // 且经度 0 ~ 360度对应的 u_extent 值为 0 ~ 2
  vec2 scale = vec2((u_extent.z - u_extent.x) / 2.0, (u_extent.w - u_extent.y) / 2.0);
  return fract(((vec2(x, y) + 1.0) / 2.0) * scale + vec2(u_extent.x / 2.0, (u_extent.y + 1.0) / 2.0));
}

void main()
{
  float speed = u_speed;
  if (iLife > 400.0 || ox < -1.0 || ox > 1.0 || oy < -1.0 || oy > 1.0) {
    float randValX = random(vec2(ix, iy)) * 2.0 - 1.0;
    float randValY = random(vec2(iy, ix)) * 2.0 - 1.0;
    float randLife = random(vec2(randValX, randValY)) * 300.0;
    vec2 texCoords = getTexCoord(randValX, randValY);
    vec4 texel = texture(u_texture, texCoords);

    ox = randValX;
    oy = randValY;
    oLife = randLife;
    oColor = vec4(texel.r, texel.g, texel.b, 1.0);
  }
  else {
    vec2 texCoords = getTexCoord(ix, iy);
    // 获取纹理色值
    vec4 texel = texture(u_texture, texCoords);
    // 求风的真实数值范围 --> 色彩数值范围的缩放比例
    vec2 scale = vec2(u_val_extent.z - u_val_extent.x, u_val_extent.w - u_val_extent.y) / 255.0;
    ox = ix + ((texel.r * 255.0 * scale.x + u_val_extent.x) / 255.0) * speed;
    oy = iy + ((texel.g * 255.0 * scale.y + u_val_extent.y) / 255.0) * speed;
    oColor = vec4(texel.r, texel.g, texel.b, 1.0);
    oLife = iLife + 1.0;
  }
}`

export const fShaderCalculate = `#version 300 es
void main() {}`

export const fShaderDraw = `#version 300 es
precision mediump float;
out vec4 color;
in vec4 vColor;
uniform float opacity;
uniform float u_withColor;
uniform vec3 u_color;
void main() {
  if(u_withColor > 0.5) {
    color = vec4(u_color, opacity);
  } else {
    color = vec4(vColor.r, vColor.g, vColor.b, opacity);
  }
}`

export const vShaderDraw = `#version 300 es
layout(location = 0) in vec2 position;
layout(location = 1) in vec4 color;

out vec4 vColor;

const float PI = 3.14159265359;
float toWGS84(float y) {
  float newY = radians(180.0 - y * 360.0);
  newY = 360.0 / PI * atan(exp(newY)) - 90.0;
  return (newY / - 180.0 + 0.5);
}
void main()
{
  // float lat = (2.0 * atan(exp(PI * position.y)) - PI / 2.0);
  // float y = (lat * 180.0 / PI) / 85.05;
  // float ratio = (radians(position.y * 85.05) + PI / 2.0) / 2.0;
  // float yy = log(tan(ratio)) / PI;
  // float y = toWGS84(position.y);
  gl_Position = vec4(position.xy, 0.0, 1.0);
  gl_PointSize = 1.2;
  vColor = color;
}`