// import React, {useContext, useEffect, useRef, useState, memo} from "react";
// import MapContext from "../../MapContext";
import ImageCanvasSource from "../../../../source/ImageCanvas.js";
import ImageLayer from "../../../../layer/Image.js";
import {
    fShaderDraw,
    fShaderCalculate,
    vShaderCalculate,
    vShaderDraw
} from "./shaders.js";
import {
    generateParticles,
    arrayEquals
} from "./utils.js";
import {
    draw,
    dataUpdate,
    createProgram,
    createBufferWithVao,
    loadImageData
} from "./webglUtils.js";
import {
    BUFFER_SIZE
} from "./consts.js";
import {
    transformExtent,
    transform
} from "../../../../proj.js";

function getScaleBounds(map, extent) {
    let mapProject = map.getView().getProjection().getCode();
    let leftTop = 0;
    let rightzbottom = 0;
    // ////////
    if (mapProject == "EPSG:3857") {
        leftTop = map.getPixelFromCoordinate(transform([-180, 85.05112877980659], "EPSG:4326", mapProject));
        rightzbottom = map.getPixelFromCoordinate(transform([180, -85.05112877980659], "EPSG:4326", mapProject));
    } else if (mapProject == "EPSG:4326") {
        leftTop = map.getPixelFromCoordinate(transform([-180, 90], "EPSG:4326", mapProject));
        rightzbottom = map.getPixelFromCoordinate(transform([180, -90], "EPSG:4326", mapProject));
    } else if (mapProject == "Albers") {
        leftTop = map.getPixelFromCoordinate(transform([-179, 90], "EPSG:4326", mapProject));
        rightzbottom = map.getPixelFromCoordinate(transform([179, -90], "EPSG:4326", mapProject));
    }

    let xWidth = Math.abs(rightzbottom[0] - leftTop[0]);
    let yWidth = Math.abs(rightzbottom[1] - leftTop[1]);
    ////////
    let leftTopZoomNumber = map.getPixelFromCoordinate([extent[0], extent[3]]);
    let leftTopZoom = [];

    leftTopZoom[0] = leftTopZoomNumber[0] - leftTop[0];
    leftTopZoom[1] = leftTopZoomNumber[1] - leftTop[1];

    let rightzbottomZoomNumber = map.getPixelFromCoordinate([extent[2], extent[1]]);
    let rightzbottomZoom = [];
    rightzbottomZoom[0] = rightzbottomZoomNumber[0] - leftTop[0];
    rightzbottomZoom[1] = rightzbottomZoomNumber[1] - leftTop[1];

    let west = leftTopZoom[0];
    let east = rightzbottomZoom[0];
    let north = leftTopZoom[1];
    let south = rightzbottomZoom[1];


    let west1 = (west / xWidth - 0.5);
    let east1 = (east / xWidth - 0.5);
    let north1 = 1 - north / yWidth;
    let south1 = 1 - south / yWidth;

    return [west1, south1, east1, north1]
}


export default function cme_pngWindyWebGLLayer(params) {

    let src = params.src;
    let trailLength = params.trailLength;
    let particlesNumber = params.particlesNumber;
    let speed = params.speed;
    let withColor = params.withColor;
    let color = params.color;
    let canvas = document.createElement("canvas");
    let particles = 0;
    const { uMin, vMin, uMax, vMax } = params;
    if (!(uMin && vMin && uMax && vMax)) {
        throw Error('缺少参数"uMin, vMin, uMax, vMax"中的一个或多个!');
    }
    const valueExtent = new Float32Array([uMin, vMin, uMax, vMax]);
    // const [ext, setExt] = [0, 0, 0, 0]
    let ext = [0, 0, 0, 0];
    // const setExt = [0, 0, 0, 0];
    let gl = canvas.getContext('webgl2');
    let programFeedback = createProgram(gl, vShaderCalculate, fShaderCalculate, ['ox', 'oy', 'oLife', 'oColor']);
    let drawProgram = createProgram(gl, vShaderDraw, fShaderDraw);
    let map = params.map;
    // const layerRef = null
    gl.useProgram(drawProgram)
    gl.uniform1f(gl.getUniformLocation(drawProgram, 'u_withColor'), withColor ? 1 : 0);
    ////////
    if (withColor) {
        gl.uniform3fv(gl.getUniformLocation(drawProgram, 'u_color'), [color.r, color.g, color.b].map(i => i / 255));
        // gl.uniform3fv(gl.getUniformLocation(drawProgram, 'u_color'), [255 ,255,0].map(i => i / 256));
    }
    gl.useProgram(programFeedback)
    gl.uniform1f(gl.getUniformLocation(programFeedback, 'u_speed'), speed / 1000);
    gl.uniform4fv(gl.getUniformLocation(programFeedback, 'u_val_extent'), valueExtent);
    particles = generateParticles(particlesNumber)
    if (!map || particles.length !== BUFFER_SIZE * particlesNumber) return;
    const initialBuffer = createBufferWithVao(gl, particlesNumber, particles)
    const buffers = new Array(trailLength).fill(-1).map(() => createBufferWithVao(gl, particlesNumber)).flatMap(i => i)
    gl.bindVertexArray(null);
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    const state = {
        vao: -1,
        buffer: 0
    }
    let dataLoaded = false

    loadImageData(gl, programFeedback, src, (value) => {
        dataLoaded = value
    })
    let animationId = null
    const canvasSource = new ImageCanvasSource({
        ratio: 1,
        projection: map.getView().getProjection().getCode(),
        // projection: 'EPSG:4326',
        canvasFunction: (extent, resolution, pixelRatio, size) => {
            if (animationId) {
                cancelAnimationFrame(animationId)
            }
            if (!arrayEquals(extent, ext)) {
                // setExt(extent)
                ext = extent;
            }
            const projCode = map.getView().getProjection().getCode();
            const extentX = transformExtent(map.getView().calculateExtent(map.getSize()), projCode, "EPSG:4326");
            // const extentX = map.getView().calculateExtent(map.getSize());
            const porjNum = +projCode.match(/(\d+)/)[1];
            // const extX = porjNum === 4326 ? 180 : 20037508.342789244;
            // // 9462156.717428254  10018754.171394622
            // const extY = porjNum === 4326 ? 90 : 20037508.342789244;

            const extX = porjNum === 4326 ? 180 : 180;
            // 9462156.717428254  10018754.171394622
            const extY = porjNum === 4326 ? 90 : 85.05;

            let newExtent = extentX.map((v, i) => v / (i % 2 ? extY : extX));
            // let newExtent = getScaleBounds(map, extentX);
            if (!dataLoaded) {
                animationId = requestAnimationFrame(() => {
                    canvasSource.changed()
                })
                return
            }
            canvas.width = size[0];
            canvas.height = size[1];
            gl.viewport(0, 0, canvas.width, canvas.height);

            const animate = () => {
                dataUpdate(programFeedback, gl, state, particlesNumber, newExtent, buffers, initialBuffer, porjNum)
                draw(gl, drawProgram, buffers, particlesNumber, state)
            }
            animate()
            animationId = requestAnimationFrame(() => {
                canvasSource.changed()
            })
            return canvas;
        },
    });

    const layer = new ImageLayer({
        source: canvasSource,
    });

    return layer
    // layerRef.current = layer;
    // map.addLayer(layer)
    // return layer;

}