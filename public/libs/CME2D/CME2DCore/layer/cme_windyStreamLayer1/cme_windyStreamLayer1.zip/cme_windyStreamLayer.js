import ImageLayer from '../../../layer/Image.js'; //import ImageLayer from 'ol/layer/Image.js';

import ImageCanvasWindSource from './ImageCanvasWindSource.js'

var cme_windyStreamLayer1 = class WindyLayerClass extends ImageLayer {
  /**
  * 渲染选项并返回一个解析为true的Promise。
  *
  * @param {Object} options - 要渲染的选项。
  * @return {Promise} 一个解析为true的Promise。
  */
  constructor() {
    // options.source = new ImageCanvasSource();
    super({});
    // // this.canvasSource=params.source;
  }
  _render(options) {

    return new Promise((resolve, reject) => {
      
      const canvasSource = new ImageCanvasWindSource(
      
        // {
        //   jsonUrl:options.jsonUrl,//"./public/data/tile.json",
        //   imageUrl:options.imageUrl,//"./public/data/0.jpg",
        // }
      );
      this.setSource(canvasSource);
      this.setProperties(options)
      canvasSource._renderFunction(options.params)
      .then(() =>{
        resolve(this)
      })
    })
  
  

    // 创建图层
    //   const imageLayer = new ImageLayer({
    //     source: canvasSource,
    //     opacity: 0.75,
    //   });
}
  /**
      * 设置函数的来源。
      *
      * @param {type} paramName - 参数的描述
      * @return {type} 返回值的描述
      */
  _setSource() {

  }
  /**
   * 对整个函数的描述。
   *
   * @param {type} paramName - 参数描述
   * @return {type} 返回值描述
   */
  _setStyle() {

  }
  /**
   * 整个函数的描述。
   *
   */
  _remove() {
    this.dispose();
    // 变量清空
  }

}
export default cme_windyStreamLayer1