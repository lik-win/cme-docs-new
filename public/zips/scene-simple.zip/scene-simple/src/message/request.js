/*
 * @Author: sjz 15103288529@163.com
 * @Date: 2024-03-15 16:58:51
 * @LastEditors: sjz 15103288529@163.com
 * @LastEditTime: 2024-03-22 09:51:16
 * @FilePath: \cme\src\message\request.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import axios from 'axios'
import QS from 'qs';

// 创建axios实例
const service = axios.create({
    // 请求URL公共部分
    baseURL: '',
    // 超时
    timeout: 10000
});

// request拦截器
service.interceptors.request.use(config => {
    // 设置 token,请求头
    return config
}, error => {
    Promise.reject(error)
});

// 响应拦截器
service.interceptors.response.use(res => {
    // 未设置状态码则默认成功状态
    const code = res.data.code || 200;
    console.log(code);
    if (code === 401) {
    } else if (code === 500) {
    } else if (code !== 200) {
      return Promise.reject("error");
    } else {
      return res.data;
    }
    
}, error => {
    return Promise.reject(error)
});
export default service