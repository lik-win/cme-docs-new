import {
  createRouter,
  createWebHashHistory,
  createWebHistory,
} from "vue-router";

const routes = [
  {
    path: "/",
    meta: {
      title: "首页",
    },
    component: () => import("@/views/home/index.vue"),
  },
  {
    path: "/routePlanning",
    meta: {
      title: "XXXX",
    },
    component: () => import("@/views/routePlanning/index.vue"),
  },
  {
    path: "/routePlanning1",
    meta: {
      title: "XXXX",
    },
    component: () => import("@/views/routePlanning/index.vue"),
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
