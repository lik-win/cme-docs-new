<template>
    <router-view></router-view>
</template>

<style lang="scss">
    @import url('./assets/style/public.less');
</style>
