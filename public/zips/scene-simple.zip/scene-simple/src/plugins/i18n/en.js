export const leftPopover = {
    objectiveProduct: "objectiveProduct",
    interactiveProduction: "interactiveProduction",
    layerType1: "Integrative map",
    layerType2: "Weather map",
    layerType3: "Business",
    layerType4: "Meteodata",
    layerType5: "Hideremarks",
}
