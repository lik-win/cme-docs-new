export const leftPopover = {
    objectiveProduct: "客观产品",
    interactiveProduction: "交互制作",
    layerType1: "综合图",
    layerType2: "气象图",
    layerType3: "业务场景",
    layerType4: "气象数据",
    layerType5: "隐藏备注",
}
