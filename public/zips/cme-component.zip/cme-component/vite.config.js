import { fileURLToPath, URL } from 'node:url'
import path from 'node:path'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
const folder = 'Example';
const globalName = 'Example';
const TARGET = 'cme-example';

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 8888,
    proxy: {
      '/cme-api/': {
        target: 'http://10.40.88.119:11000',
        changeOrigin: true,
        rewrite: p => p.replace(/^\/cme-api\b/, '')
      }
    }
  },
  build: {
    minify: 'esbuild',
    lib: {
      // 组件入口文件
      entry: path.resolve(__dirname, `src/components/${folder}/index.js`),
      // 打包成umd模块后全局变量的名称
      name: globalName,
      // 模块类型
      formats: ['es', 'umd'],
      // 文件名称（可包含路径）
      fileName: fmt => `${TARGET}/${fmt}/${TARGET}.js`
    },
    rollupOptions: {
      // 排除掉第三方库
      external: ['CME2D', 'cme2d', 'vue', 'echarts', 'turf'],
      output: {
        assetFileNames: info => {
          console.log(info);
          if (info.name.endsWith('.css')) {
            return `${TARGET}/${TARGET}.css`;
          }
          return info.name;
        },
        globals: {
          vue: 'Vue',
          CME2D: 'CME2D',
          cme2d: 'cme2d',
          echarts: 'echarts',
          turf: 'turf'
        }
      }
    },
  },

  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
})
