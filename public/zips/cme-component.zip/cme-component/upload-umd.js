import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import minimist from 'minimist';
import archiver from 'archiver';
import FormData from 'form-data';
import axios from 'axios';

const args = minimist(process.argv.slice(2));

function getPath(src) {
  return path.resolve(path.dirname('./'), src);
}

const name = args.name || args.n;
const version = args.version || args.v;

if (!(name && version)) {
  throw Error('命令缺少参数，文件名称(--name/-n)或版本号(--version/-v)参数缺失！')
}

function copyFiles(fmt) {
  const styleUrl = `dist/${name}/${name}.css`;
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(styleUrl)) {
      return resolve();
    }
    const targetUrl = `dist/${name}/${fmt}/${name}.css`;
    fs.copyFile(getPath(styleUrl), getPath(targetUrl), err => {
      if (err) return reject(err);
      resolve();
    });
  });
}

function getFileList() {
  const dirPath = `dist/${name}/umd`;
  return new Promise((resolve, reject) => {
    fs.readdir(dirPath, (err, files) => {
      if (err) {
        return reject(err);
      }
      resolve(files);
    });
  });
}

function zipFiles(files) {
  const zipUrl = `dist/${name}/${name}-${version}.zip`;
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(zipUrl);
    const archive = archiver('zip', {
      zlib: { level: 9 } // 压缩级别
    });
    files.forEach(fileName => {
      console.log('添加文件：', name);
      const path = `dist/${name}/umd/${fileName}`;
      archive.file(path, { name: fileName });
    });
    archive.pipe(output);
    archive.on('finish', () => {
      output.close();
      resolve();
    });
    archive.on('error', err => reject && reject(err));
    archive.finalize();
  });
}

function uploadZip() {
  const zipUrl = path.resolve(`dist/${name}/${name}-${version}.zip`);
  console.log('zipUrl =>', zipUrl);
  const form = FormData();
  form.append('file', fs.createReadStream(zipUrl));
  var config = {
    method: 'post',
    url: 'http://10.40.88.119:11000/fileserver/api/upload',
    headers: { ...form.getHeaders() },
    timeout: 10000,
    data: form
  };
  axios(config).then(() => {
    console.log('upload success!');
  }).catch(err => {
    console.error('upload failed:', err);
  });
}

// 上传
copyFiles('umd').then(getFileList).then(zipFiles).then(uploadZip);

