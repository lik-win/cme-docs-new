import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import minimist from 'minimist';

const args = minimist(process.argv.slice(2));

function getPath(src) {
  return path.resolve(path.dirname('./'), src);
}

const fileOps = { encoding: 'utf-8' };

const name = args.name || args.n;
const version = args.version || args.v;
const _main = args.main || args.m || name;
const mainFile = /\.\wjs$/i.test(_main) ? _main : `${_main}.js`;

if (!(name && version)) {
  throw Error('命令缺少参数，文件名称(--name/-n)或版本号(--version/-v)参数缺失！')
}

const packageInfo = `{
  "name": "${name}",
  "version": "${version}",
  "description": "${name}",
  "main": "${mainFile}",
  "scripts": {
    "test": "echo \\\"Error: no test specified\\\" && exit 1"
  },
  "keywords": ["${name}"],
  "author": "fengyunqixiang",
  "private": false,
  "license": "ISC"
}`;

function copyFiles(fmt) {
  const styleUrl = `dist/${name}/${name}.css`;
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(styleUrl)) {
      return resolve();
    }
    const targetUrl = `dist/${name}/${fmt}/${name}.css`;
    fs.copyFile(getPath(styleUrl), getPath(targetUrl), err => {
      if (err) return reject(err);
      resolve();
    });
  });
}


function createPackageJson() {
  return new Promise((resolve, reject) => {
    const distPath = `dist/${name}/es/${name}/package.json`;
    fs.writeFile(getPath(distPath), packageInfo, fileOps, err => {
      if (err) return reject(err);
      resolve();
    });
  });
}

function publishNpm() {
  return execa("npm", ["publish"], {
    env: {
      ...process.env,
      npm_config_registry: "http://cme.leonhan.com:3526/nexus/repository/npm-release/",
    }
  });
}

// 上传 npm 包
Promise.all([copyFiles('es'), createPackageJson()]).then(() => {
  process.chdir(`dist/${name}/es`);
  publishNpm();
});

