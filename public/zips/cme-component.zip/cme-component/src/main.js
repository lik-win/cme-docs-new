import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'

// 导入组件
import Example from './components/Example/index.js';

const vueApp = createApp(App);
// 安装vue组件
vueApp.use(Example);
vueApp.mount('#app');
