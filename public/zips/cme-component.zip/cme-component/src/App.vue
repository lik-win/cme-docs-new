<template>
  <main>
    <cme-example />
  </main>
</template>
