import Example from "./Example.vue";

Example.install = function (Vue) {
  Vue.component("cme-example", Example);
};
export default Example;
