import WindyBarb from "./index.vue";
//风向杆组件
WindyBarb.install = function (Vue) {
  Vue.component("CME-WindyBarb", WindyBarb);
};
export {  WindyBarb };