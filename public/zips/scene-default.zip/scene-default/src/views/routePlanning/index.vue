<template>
    <div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.core-operate{
    display: flex;
    height:calc(100vh - 134px);
}
</style>